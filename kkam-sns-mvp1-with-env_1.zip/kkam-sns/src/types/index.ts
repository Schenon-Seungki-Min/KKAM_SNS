// KKAM_SNS 타입 정의

// 트렌드 데이터 타입
export interface TrendData {
  keyword: string;
  score: number; // 0-100 상대적 인기도
  source: 'google' | 'naver' | 'pubmed';
  category?: string;
  timestamp: Date;
  relatedQueries?: string[];
}

// Google Trends 응답
export interface GoogleTrendResult {
  keyword: string;
  value: number;
  formattedValue: string;
  relatedQueries: string[];
}

// 네이버 검색어 Lab 응답
export interface NaverTrendResult {
  title: string;
  keywords: string[];
  data: {
    period: string;
    ratio: number;
  }[];
}

// PubMed 논문 데이터
export interface PubMedArticle {
  pmid: string;
  title: string;
  abstract: string;
  authors: string[];
  publishDate: string;
  journal: string;
  keywords: string[];
}

// 콘텐츠 추천
export interface ContentSuggestion {
  id: string;
  trend: TrendData;
  title: string;
  hook: string; // 첫 문장 (훅)
  body: string;
  hashtags: string[];
  platform: 'threads' | 'instagram' | 'both';
  createdAt: Date;
}

// 생성된 콘텐츠
export interface GeneratedContent {
  id: string;
  suggestion: ContentSuggestion;
  text: string;
  imageUrl?: string;
  status: 'draft' | 'ready' | 'posted';
  postedAt?: Date;
}

// 대시보드 요약
export interface DashboardSummary {
  topTrends: TrendData[];
  suggestions: ContentSuggestion[];
  recentContent: GeneratedContent[];
  lastUpdated: Date;
}
